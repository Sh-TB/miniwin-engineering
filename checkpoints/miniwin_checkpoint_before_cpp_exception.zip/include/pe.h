#ifndef MINWIN_PE_H
#define MINWIN_PE_H

#include <stdint.h>

#pragma pack(push, 1)

/* DOS Header */
typedef struct {
    uint8_t  e_magic[2];       /* MZ */
    uint16_t e_cblp;
    uint16_t e_cp;
    uint16_t e_crlc;
    uint16_t e_cparhdr;
    uint16_t e_minalloc;
    uint16_t e_maxalloc;
    uint16_t e_ss;
    uint16_t e_sp;
    uint16_t e_csum;
    uint16_t e_ip;
    uint16_t e_cs;
    uint16_t e_lfarlc;
    uint16_t e_ovno;
    uint16_t e_res[4];
    uint16_t e_oemid;
    uint16_t e_oeminfo;
    uint16_t e_res2[10];
    uint32_t e_lfanew;
} DosHeader;

/* PE Signature */
typedef struct {
    uint8_t  signature[4]; /* PE\\0\\0 */
} PeSignature;

/* COFF Header */
typedef struct {
    uint16_t Machine;
    uint16_t NumberOfSections;
    uint32_t TimeDateStamp;
    uint32_t PointerToSymbolTable;
    uint32_t NumberOfSymbols;
    uint16_t SizeOfOptionalHeader;
    uint16_t Characteristics;
} CoffHeader;

/* PE32+ Optional Header */
typedef struct {
    uint16_t Magic;                    /* 0x020b for PE32+ */
    uint8_t  MajorLinkerVersion;
    uint8_t  MinorLinkerVersion;
    uint32_t SizeOfCode;
    uint32_t SizeOfInitializedData;
    uint32_t SizeOfUninitializedData;
    uint32_t AddressOfEntryPoint;
    uint32_t BaseOfCode;
    uint64_t ImageBase;
    uint32_t SectionAlignment;
    uint32_t FileAlignment;
    uint16_t MajorOperatingSystemVersion;
    uint16_t MinorOperatingSystemVersion;
    uint16_t MajorImageVersion;
    uint16_t MinorImageVersion;
    uint16_t MajorSubsystemVersion;
    uint16_t MinorSubsystemVersion;
    uint32_t Win32VersionValue;
    uint32_t SizeOfImage;
    uint32_t SizeOfHeaders;
    uint32_t CheckSum;
    uint16_t Subsystem;
    uint16_t DllCharacteristics;
    uint64_t SizeOfStackReserve;
    uint64_t SizeOfStackCommit;
    uint64_t SizeOfHeapReserve;
    uint64_t SizeOfHeapCommit;
    uint32_t LoaderFlags;
    uint32_t NumberOfRvaAndSizes;
    /* DataDirectory follows */
} PeOptHeader64;

/* Data Directory Entry */
typedef struct {
    uint32_t VirtualAddress;
    uint32_t Size;
} DataDirectory;

/* Section Header */
typedef struct {
    uint8_t  Name[8];
    uint32_t VirtualSize;
    uint32_t VirtualAddress;
    uint32_t SizeOfRawData;
    uint32_t PointerToRawData;
    uint32_t PointerToRelocations;
    uint32_t PointerToLinenumbers;
    uint16_t NumberOfRelocations;
    uint16_t NumberOfLinenumbers;
    uint32_t Characteristics;
} SectionHeader;

/* Import Directory Entry */
typedef struct {
    uint32_t OriginalFirstThunk;  /* ILT RVA (0 = use IAT) */
    uint32_t TimeDateStamp;
    uint32_t ForwarderChain;
    uint32_t Name;
    uint32_t FirstThunk;         /* IAT RVA */
} ImportDirectoryEntry;

/* TLS Directory (PE32+) */
typedef struct {
    uint64_t StartAddressOfRawData;
    uint64_t EndAddressOfRawData;
    uint64_t AddressOfIndex;
    uint64_t AddressOfCallBacks;
    uint32_t SizeOfZeroFill;
    uint32_t Characteristics;
} TlsDirectory64;

#pragma pack(pop)

/* Data Directory indices */
#define DD_EXPORT          0
#define DD_IMPORT          1
#define DD_RESOURCE        2
#define DD_EXCEPTION       3
#define DD_SECURITY        4
#define DD_BASERELOC       5
#define DD_DEBUG           6
#define DD_ARCHITECTURE    7
#define DD_GLOBALPTR       8
#define DD_TLS             9
#define DD_LOAD_CONFIG    10
#define DD_BOUND_IMPORT   11
#define DD_IAT            12
#define DD_DELAY_IMPORT   13
#define DD_CLR            14
#define DD_RESERVED       15

/* Section characteristic flags */
#define SCN_CNT_CODE          0x00000020
#define SCN_CNT_INITIALIZED   0x00000040
#define SCN_CNT_UNINITIALIZED 0x00000080
#define SCN_MEM_DISCARDABLE   0x02000000
#define SCN_MEM_NOT_CACHED    0x04000000
#define SCN_MEM_NOT_PAGED     0x08000000
#define SCN_MEM_SHARED        0x10000000
#define SCN_MEM_EXECUTE       0x20000000
#define SCN_MEM_READ          0x40000000
#define SCN_MEM_WRITE         0x80000000

/* Constants */
#define PE32PLUS_MAGIC 0x020b
#define KERNEL32_STDCALL 0

static inline void* rva_to_ptr(uint8_t* base, uint32_t rva) {
    return (void*)(base + rva);
}

#endif /* MINWIN_PE_H */
