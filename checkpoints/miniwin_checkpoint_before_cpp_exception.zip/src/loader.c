/*
 * MiniWin PE Loader v0.1
 * Minimal Windows x64 PE runtime for Linux
 * Executes Windows PE applications without Wine
 *
 * Target: upx_decompressed.exe --version
 * DLLs: KERNEL32.DLL (68 imports) + msvcrt.dll (94 imports)
 *
 * Build: gcc -o minwin_loader loader.c -O2 -no-pie -g
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <time.h>
#include <errno.h>
#include <signal.h>
#include <setjmp.h>
#include <locale.h>
#include <ctype.h>
#include <stdarg.h>
#include <pthread.h>
#include <wchar.h>
#include <dlfcn.h>

#include "../include/pe.h"

/* ============================================================
 * Global State
 * ============================================================ */

static const char* g_exe_path = NULL;
static char g_cmdline_ansi[4096];
static wchar_t g_cmdline_wide[4096];
static char* g_argv[256];
static int g_argc = 0;
static int g_app_type = 1;          /* _CONSOLE_APP */
static int g_fmode_val = 0;           /* _O_TEXT */
static int g_commode_val = 0;         /* default commode */
static int g_last_error = 0;

/* Image state */
static uint8_t* g_image_base = NULL;
static uint64_t g_image_size = 0;
static uint64_t g_entry_point = 0;

/* Trampoline area — reserved for future use */

/* API trace */
static FILE* g_trace_log = NULL;
#define MW_TRACE(fmt, ...) do { \
    if (g_trace_log) { \
        fprintf(g_trace_log, "[API] " fmt "\n", ##__VA_ARGS__); \
        fflush(g_trace_log); \
    } else { \
        fprintf(stderr, "[TRACE] " fmt "\n", ##__VA_ARGS__); \
    } \
} while(0)

/* Handle table */
#define MAX_HANDLES 64
static void* g_handle_table[MAX_HANDLES];
static int    g_handle_count = 0;

static void* alloc_handle(void* ptr) {
    if (g_handle_count < MAX_HANDLES) {
        int h = g_handle_count + 4; /* Start handles at 4 */
        g_handle_table[g_handle_count++] = ptr;
        return (void*)(uintptr_t)h;
    }
    return (void*)(uintptr_t)-1; /* INVALID_HANDLE_VALUE */
}

/* ============================================================
 * TEB / PEB Structures
 * ============================================================ */

/* Fake TEB (Thread Environment Block) - minimal fields */
static uint8_t g_teb_storage[4096] __attribute__((aligned(4096)));
static uint8_t g_peb_storage[4096] __attribute__((aligned(4096)));
static uint8_t g_params_storage[4096] __attribute__((aligned(4096)));

/* RTL_USER_PROCESS_PARAMETERS layout (x64) */
struct FakeProcessParams {
    uint64_t MaximumLength;           /* 0x00 */
    uint64_t Length;                  /* 0x08 */
    uint32_t Flags;                   /* 0x10 */
    uint32_t DebugFlags;              /* 0x14 */
    uint64_t ConsoleHandle;           /* 0x18 */
    uint32_t ConsoleFlags;            /* 0x20 */
    uint32_t StdInputHandle;          /* 0x24 */
    uint32_t StdOutputHandle;         /* 0x28 */
    uint32_t StdErrorHandle;          /* 0x2C */
    uint8_t  pad1[16];                /* 0x30 */
    /* UNICODE_STRING CommandLine at 0x60 */
    uint16_t CmdLen;                  /* 0x60 */
    uint16_t CmdMaxLen;               /* 0x62 */
    uint64_t CmdBuffer;               /* 0x68 */
    /* UNICODE_STRING ImagePathName at 0x70 */
    uint16_t ImgPathLen;              /* 0x70 */
    uint16_t ImgPathMaxLen;           /* 0x72 */
    uint64_t ImgPathBuffer;           /* 0x78 */
};

static void setup_teb_peb(void) {
    memset(g_teb_storage, 0, sizeof(g_teb_storage));
    memset(g_peb_storage, 0, sizeof(g_peb_storage));
    memset(g_params_storage, 0, sizeof(g_params_storage));

    uint8_t* teb = g_teb_storage;
    uint8_t* peb = g_peb_storage;
    struct FakeProcessParams* params = (struct FakeProcessParams*)g_params_storage;

    /* Get actual stack info */
    void* stack_base = NULL;
    size_t stack_size = 0;
    pthread_attr_t attr;
    pthread_getattr_np(pthread_self(), &attr);
    pthread_attr_getstack(&attr, &stack_base, &stack_size);
    pthread_attr_destroy(&attr);
    uint8_t* stack_top = (uint8_t*)stack_base + stack_size;

    /* TEB layout (x64 Windows)
     * 0x00 ExceptionList
     * 0x08 StackBase
     * 0x10 StackLimit
     * 0x18 SubSystemTib
     * 0x20 FiberData
     * 0x28 Version (4) + ArbitraryUserPointer (4)
     * 0x30 Self (pointer to TEB)
     * 0x38 EnvironmentPointer
     * 0x40 ClientId.UniqueProcess
     * 0x48 ClientId.UniqueThread
     * 0x50 RpcHandle
     * 0x58 TlsSlots[0] (first TLS slot)
     * 0x60 PEB pointer
     * 0x68 LastErrorValue
     */
    *(uint64_t*)(teb + 0x00) = 0;                    /* ExceptionList = NULL */
    *(uint64_t*)(teb + 0x08) = (uint64_t)stack_top;  /* StackBase */
    *(uint64_t*)(teb + 0x10) = (uint64_t)stack_base; /* StackLimit */
    *(uint64_t*)(teb + 0x30) = (uint64_t)teb;        /* Self */
    *(uint64_t*)(teb + 0x40) = 1234;                 /* ClientId.UniqueProcess */
    *(uint64_t*)(teb + 0x48) = 5678;                 /* ClientId.UniqueThread */
    *(uint64_t*)(teb + 0x60) = (uint64_t)peb;        /* PEB pointer */
    *(uint32_t*)(teb + 0x68) = 0;                    /* LastErrorValue */

    /* PEB layout (minimal)
     * 0x00 InheritedAddressSpace (1)
     * 0x01 ReadImageFileExecOptions (1)
     * 0x02 BeingDebugged (1)
     * 0x03 BitField (1)
     * 0x08 Mutant
     * 0x10 ImageBaseAddress
     * 0x18 Ldr (PEB_LDR_DATA*)
     * 0x20 ProcessParameters
     * 0x28 SubSystemMajorVersion (2) + MinorVersion (2) + padding (4)
     */
    *(uint64_t*)(peb + 0x00) = 0;                    /* InheritedAddressSpace=0, ReadImageFileExecOptions=0, BeingDebugged=0 */
    *(uint64_t*)(peb + 0x10) = (uint64_t)g_image_base; /* ImageBaseAddress */
    *(uint64_t*)(peb + 0x18) = 0;                    /* Ldr = NULL */
    *(uint64_t*)(peb + 0x20) = (uint64_t)params;     /* ProcessParameters */

    /* Process Parameters */
    size_t cmd_len = strlen(g_cmdline_ansi) * 2; /* wide char bytes */
    params->MaximumLength = sizeof(struct FakeProcessParams);
    params->Length = sizeof(struct FakeProcessParams);
    params->Flags = 0;
    params->DebugFlags = 0;
    params->ConsoleHandle = (uint64_t)(uintptr_t)(-1); /* INVALID_HANDLE_VALUE */
    params->ConsoleFlags = 0;
    params->StdInputHandle = 0;  /* STD_INPUT_HANDLE = -10 → fd 0 */
    params->StdOutputHandle = 1; /* STD_OUTPUT_HANDLE = -11 → fd 1 */
    params->StdErrorHandle = 2;  /* STD_ERROR_HANDLE = -12 → fd 2 */
    params->CmdLen = (uint16_t)cmd_len;
    params->CmdMaxLen = (uint16_t)(cmd_len + 4);
    params->CmdBuffer = (uint64_t)(uintptr_t)g_cmdline_wide;

    /* Set GS base to TEB */
    syscall(SYS_arch_prctl, 0x1001 /* ARCH_SET_GS */, (uint64_t)(uintptr_t)teb);
}

/* ============================================================
 * Trampoline Generation (Windows → System V ABI)
 * ============================================================ */

/*
 * Windows x64 ABI: RCX, RDX, R8, R9, then stack (with 32-byte shadow space)
 * System V ABI:   RDI, RSI, RDX, RCX, R8, R9, then stack (no shadow space)
 *
 * Trampoline converts and adjusts stack.
 * For non-variadic functions, we use __attribute__((ms_abi)) instead.
 * Trampolines are only used for variadic functions.
 */

static void write_trampoline(void* addr, void* target) {
    uint8_t* p = (uint8_t*)addr;
    int64_t rel = (int64_t)(uintptr_t)target - (int64_t)(uintptr_t)(p + 24);

    /* sub rsp, 0x20     */  p[0] = 0x48; p[1] = 0x83; p[2] = 0xEC; p[3] = 0x20;
    /* mov rdi, rcx      */  p[4] = 0x48; p[5] = 0x89; p[6] = 0xCF;
    /* mov rsi, rdx      */  p[7] = 0x48; p[8] = 0x89; p[9] = 0xD6;
    /* mov rdx, r8       */  p[10] = 0x4D; p[11] = 0x89; p[12] = 0xC2;
    /* mov rcx, r9       */  p[13] = 0x49; p[14] = 0x89; p[15] = 0xC9;
    /* call rel32         */  p[16] = 0xE8;
    memcpy(p + 17, &rel, 4);
    /* add rsp, 0x20     */  p[21] = 0x48; p[22] = 0x83; p[23] = 0xC4; p[24] = 0x20;
    /* ret                */  p[25] = 0xC3;
}

/* Special trampoline for printf-like variadic functions.
 * Since va_list ABI differs between Windows and System V,
 * we intercept the format string and use vsnprintf internally.
 */

/* Forward declarations for System V ABI wrappers */
static int mw_printf_sv(const char* fmt, ...);
static int mw_fprintf_sv(void* file, const char* fmt, ...);
static int mw_vfprintf_sv(void* file, const char* fmt, void* ap);

/*
 * For printf/fprintf, we can't easily trampoline variadic args.
 * Instead, write asm trampolines that call ms_abi wrappers.
 * These wrappers use the format string + fixed-position args.
 *
 * Strategy: printf is called with at most a few args in registers.
 * For upx --version, printf("upx %s\n", version) has 2 args.
 * We implement printf in ms_abi directly, using vsnprintf to buffer.
 */

/* ============================================================
 * KERNEL32.DLL Stubs (ms_abi calling convention)
 * ============================================================ */

static void* g_unhandled_exception_filter = NULL;
static void* g_veh_handlers[16];
static int g_veh_count = 0;

__attribute__((ms_abi)) void* mw_AddVectoredExceptionHandler(uint32_t first, void* handler) {
    MW_TRACE("AddVectoredExceptionHandler(first=%u, handler=%p)", first, handler);
    if (g_veh_count < 16) {
        if (first) {
            memmove(g_veh_handlers + 1, g_veh_handlers, g_veh_count * sizeof(void*));
            g_veh_handlers[0] = handler;
        } else {
            g_veh_handlers[g_veh_count] = handler;
        }
        g_veh_count++;
        return handler;
    }
    return NULL;
}

__attribute__((ms_abi)) uint8_t mw_RemoveVectoredExceptionHandler(void* h) {
    MW_TRACE("RemoveVectoredExceptionHandler(%p)", h);
    for (int i = 0; i < g_veh_count; i++) {
        if (g_veh_handlers[i] == h) {
            memmove(g_veh_handlers + i, g_veh_handlers + i + 1,
                    (g_veh_count - i - 1) * sizeof(void*));
            g_veh_count--;
            return 1;
        }
    }
    return 0;
}

__attribute__((ms_abi)) int mw_CloseHandle(void* h) {
    MW_TRACE("CloseHandle(handle=%p)", h);
    return 1; /* TRUE */
}

__attribute__((ms_abi)) void* mw_CreateEventA(void* attr, int manual, int init, const char* name) {
    MW_TRACE("CreateEventA(manual=%d, init=%d, name=%s)", manual, init, name ? name : "NULL");
    return alloc_handle((void*)(uintptr_t)1);
}

__attribute__((ms_abi)) void* mw_CreateSemaphoreA(void* attr, int32_t init, int32_t max, const char* name) {
    MW_TRACE("CreateSemaphoreA(init=%d, max=%d, name=%s)", init, max, name ? name : "NULL");
    return alloc_handle((void*)(uintptr_t)1);
}

__attribute__((ms_abi)) void mw_DebugBreak(void) {
    MW_TRACE("DebugBreak()");
}

/* Critical Section state */
struct MwCritSec {
    pthread_mutex_t mutex;
    int initialized;
};

__attribute__((ms_abi)) void mw_InitializeCriticalSection(void* cs) {
    if (!cs) return;
    struct MwCritSec* mcs = (struct MwCritSec*)cs;
    if (!mcs->initialized) {
        pthread_mutexattr_t attr;
        pthread_mutexattr_init(&attr);
        pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
        pthread_mutex_init(&mcs->mutex, &attr);
        pthread_mutexattr_destroy(&attr);
        mcs->initialized = 1;
        /* Zero out the rest of the CRITICAL_SECTION structure (Windows CRITICAL_SECTION is 40 bytes) */
        size_t cs_total = 40; /* sizeof(CRITICAL_SECTION) on Windows x64 */
        if (cs_total > sizeof(struct MwCritSec))
            memset((uint8_t*)cs + sizeof(struct MwCritSec), 0, cs_total - sizeof(struct MwCritSec));
    }
    MW_TRACE("InitializeCriticalSection(%p)", cs);
}

__attribute__((ms_abi)) void mw_DeleteCriticalSection(void* cs) {
    if (!cs) return;
    struct MwCritSec* mcs = (struct MwCritSec*)cs;
    if (mcs->initialized) {
        pthread_mutex_destroy(&mcs->mutex);
        mcs->initialized = 0;
    }
    MW_TRACE("DeleteCriticalSection(%p)", cs);
}

__attribute__((ms_abi)) void mw_EnterCriticalSection(void* cs) {
    if (!cs) return;
    struct MwCritSec* mcs = (struct MwCritSec*)cs;
    if (!mcs->initialized) mw_InitializeCriticalSection(cs);
    pthread_mutex_lock(&mcs->mutex);
    MW_TRACE("EnterCriticalSection(%p)", cs);
}

__attribute__((ms_abi)) void mw_LeaveCriticalSection(void* cs) {
    if (!cs) return;
    struct MwCritSec* mcs = (struct MwCritSec*)cs;
    if (mcs->initialized) pthread_mutex_unlock(&mcs->mutex);
    MW_TRACE("LeaveCriticalSection(%p)", cs);
}

__attribute__((ms_abi)) int mw_TryEnterCriticalSection(void* cs) {
    if (!cs) return 0;
    struct MwCritSec* mcs = (struct MwCritSec*)cs;
    if (!mcs->initialized) mw_InitializeCriticalSection(cs);
    int ret = (pthread_mutex_trylock(&mcs->mutex) == 0) ? 1 : 0;
    MW_TRACE("TryEnterCriticalSection(%p) = %d", cs, ret);
    return ret;
}

__attribute__((ms_abi)) int mw_DuplicateHandle(void* src, void* src_h, void* tgt, void** tgt_h,
    uint32_t access, int inh, uint32_t opts) {
    MW_TRACE("DuplicateHandle(src_h=%p, tgt_h=%p)", src_h, tgt_h);
    if (tgt_h) *tgt_h = src_h; /* Just copy the handle */
    return 1; /* TRUE */
}

/* Console */
__attribute__((ms_abi)) int mw_GetConsoleMode(void* h, uint32_t* mode) {
    MW_TRACE("GetConsoleMode(handle=%p)", h);
    if (mode) *mode = 0x0003; /* ENABLE_ECHO_INPUT | ENABLE_LINE_INPUT */
    return 1;
}

__attribute__((ms_abi)) int mw_GetConsoleScreenBufferInfo(void* h, void* info) {
    MW_TRACE("GetConsoleScreenBufferInfo(handle=%p)", h);
    if (info) {
        memset(info, 0, 48); /* CONSOLE_SCREEN_BUFFER_INFO is ~48 bytes */
        *(uint16_t*)((uint8_t*)info + 0) = 80;   /* dwSize.X */
        *(uint16_t*)((uint8_t*)info + 2) = 25;   /* dwSize.Y */
        *(uint16_t*)((uint8_t*)info + 4) = 80;   /* dwCursorPosition.X */
        *(uint16_t*)((uint8_t*)info + 6) = 0;    /* dwCursorPosition.Y */
        *(uint16_t*)((uint8_t*)info + 8) = 0x0007; /* wAttributes */
    }
    return 1;
}

__attribute__((ms_abi)) int mw_GetConsoleCursorInfo(void* h, void* info) {
    MW_TRACE("GetConsoleCursorInfo(handle=%p)", h);
    if (info) {
        *(uint32_t*)info = 1;  /* dwSize = 25% */
        *((uint8_t*)info + 4) = 1; /* bVisible = TRUE */
    }
    return 1;
}

__attribute__((ms_abi)) int mw_SetConsoleCursorInfo(void* h, void* info) {
    MW_TRACE("SetConsoleCursorInfo(handle=%p)", h);
    return 1;
}

__attribute__((ms_abi)) int mw_SetConsoleCursorPosition(void* h, uint32_t x, uint32_t y) {
    MW_TRACE("SetConsoleCursorPosition(handle=%p, x=%u, y=%u)", h, x, y);
    return 1;
}

__attribute__((ms_abi)) int mw_SetConsoleTextAttribute(void* h, uint16_t attr) {
    MW_TRACE("SetConsoleTextAttribute(handle=%p, attr=0x%x)", h, attr);
    return 1;
}

__attribute__((ms_abi)) int mw_WriteConsoleOutputA(void* h, void* buf, uint32_t size,
    uint32_t* coord, void* region) {
    MW_TRACE("WriteConsoleOutputA(handle=%p, size=%u)", h, size);
    /* Could write the buffer to stdout if needed */
    if (region) memset(region, 0, 16);
    return 1;
}

/* Process/Thread */
__attribute__((ms_abi)) void* mw_GetCurrentProcess(void) {
    return (void*)(uintptr_t)(-1); /* PSEUDO_HANDLE_CURRENT_PROCESS */
}

__attribute__((ms_abi)) uint32_t mw_GetCurrentProcessId(void) {
    return 1234;
}

__attribute__((ms_abi)) void* mw_GetCurrentThread(void) {
    return (void*)(uintptr_t)(-2); /* PSEUDO_HANDLE_CURRENT_THREAD */
}

__attribute__((ms_abi)) uint32_t mw_GetCurrentThreadId(void) {
    return 5678;
}

__attribute__((ms_abi)) int mw_GetFileTime(void* h, void* ct, void* at, void* wt) {
    MW_TRACE("GetFileTime()");
    return 0;
}

__attribute__((ms_abi)) int mw_GetHandleInformation(void* h, uint32_t* flags) {
    MW_TRACE("GetHandleInformation()");
    return 0;
}

__attribute__((ms_abi)) uint32_t mw_GetLastError(void) {
    uint32_t err = g_last_error;
    MW_TRACE("GetLastError() = %u", err);
    return err;
}

__attribute__((ms_abi)) void* mw_GetModuleHandleA(const char* name) {
    MW_TRACE("GetModuleHandleA(name=%s)", name ? name : "NULL");
    if (name == NULL || name[0] == '\0') return g_image_base;
    return NULL;
}

__attribute__((ms_abi)) void* mw_GetProcAddress(void* module, const char* name) {
    MW_TRACE("GetProcAddress(module=%p, name=%s)", module, name ? name : "NULL");
    return NULL;
}

__attribute__((ms_abi)) int mw_GetProcessAffinityMask(void* h, uint64_t* mask, uint64_t* sys) {
    MW_TRACE("GetProcessAffinityMask()");
    if (mask) *mask = 1;
    return 1;
}

__attribute__((ms_abi)) void mw_GetStartupInfoA(void* info) {
    MW_TRACE("GetStartupInfoA(info=%p)", info);
    if (info) {
        memset(info, 0, 104); /* STARTUPINFOA is 104 bytes on x64 */
        *(uint32_t*)((uint8_t*)info + 0) = 104; /* cb = sizeof(STARTUPINFOA) */
        *(uint32_t*)((uint8_t*)info + 8) = 0;   /* dwFlags = 0 */
        *(uint16_t*)((uint8_t*)info + 60) = 80; /* dwXSize */
        *(uint16_t*)((uint8_t*)info + 64) = 25; /* dwYSize */
        *(uint16_t*)((uint8_t*)info + 68) = 80; /* dwXCountChars */
        *(uint16_t*)((uint8_t*)info + 72) = 300; /* dwYCountChars */
        /* Std handles at offsets 80, 88, 96 */
        *(uint64_t*)((uint8_t*)info + 80) = 0; /* hStdInput */
        *(uint64_t*)((uint8_t*)info + 88) = 1; /* hStdOutput */
        *(uint64_t*)((uint8_t*)info + 96) = 2; /* hStdError */
    }
}

__attribute__((ms_abi)) void* mw_GetStdHandle(int32_t nStdHandle) {
    /* STD_INPUT_HANDLE=-10, STD_OUTPUT_HANDLE=-11, STD_ERROR_HANDLE=-12 */
    void* h = (void*)(uintptr_t)(-nStdHandle);
    MW_TRACE("GetStdHandle(%d) = %p", nStdHandle, h);
    return h;
}

__attribute__((ms_abi)) void mw_GetSystemTimeAsFileTime(void* ft) {
    MW_TRACE("GetSystemTimeAsFileTime()");
    if (ft) {
        struct timeval tv;
        gettimeofday(&tv, NULL);
        /* FILETIME: 100-nanosecond intervals since 1601-01-01 */
        /* Unix epoch (1970) is 11644473600 seconds after 1601 */
        uint64_t t = (uint64_t)tv.tv_sec * 10000000ULL + (uint64_t)tv.tv_usec * 10ULL;
        t += 116444736000000000ULL;
        *(uint64_t*)ft = t;
    }
}

__attribute__((ms_abi)) int mw_GetThreadContext(void* h, void* ctx) {
    MW_TRACE("GetThreadContext()");
    return 0;
}

__attribute__((ms_abi)) int mw_GetThreadPriority(void* h) {
    MW_TRACE("GetThreadPriority()");
    return 0;
}

__attribute__((ms_abi)) uint32_t mw_GetTickCount(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    uint32_t ms = (uint32_t)(ts.tv_sec * 1000 + ts.tv_nsec / 1000000);
    MW_TRACE("GetTickCount() = %u", ms);
    return ms;
}

__attribute__((ms_abi)) int mw_IsDBCSLeadByteEx(int cp, uint8_t b) {
    return 0;
}

__attribute__((ms_abi)) int mw_IsDebuggerPresent(void) {
    MW_TRACE("IsDebuggerPresent() = FALSE");
    return 0;
}

__attribute__((ms_abi)) int mw_MultiByteToWideChar(uint32_t cp, uint32_t flags,
    const char* src, int srclen, wchar_t* dst, int dstlen) {
    MW_TRACE("MultiByteToWideChar(cp=%u, srclen=%d, dstlen=%d)", cp, srclen, dstlen);
    if (!src) return 0;
    int slen = srclen;
    if (slen < 0) slen = (int)strlen(src);
    if (dstlen == 0) return slen;
    int wlen = mbstowcs(dst, src, dstlen);
    return (wlen < 0) ? 0 : wlen;
}

__attribute__((ms_abi)) void* mw_OpenProcess(uint32_t access, int inh, uint32_t pid) {
    MW_TRACE("OpenProcess()");
    return NULL;
}

__attribute__((ms_abi)) void mw_OutputDebugStringA(const char* str) {
    MW_TRACE("OutputDebugStringA(%s)", str ? str : "NULL");
    if (str) fprintf(stderr, "[DEBUG] %s", str);
}

__attribute__((ms_abi)) int mw_QueryPerformanceCounter(int64_t* lp) {
    MW_TRACE("QueryPerformanceCounter()");
    if (lp) {
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        *lp = (int64_t)ts.tv_sec * 1000000000LL + ts.tv_nsec;
    }
    return 1;
}

__attribute__((ms_abi)) int mw_QueryPerformanceFrequency(int64_t* lp) {
    MW_TRACE("QueryPerformanceFrequency()");
    if (lp) *lp = 1000000000LL; /* nanoseconds */
    return 1;
}

__attribute__((ms_abi)) void mw_RaiseException(uint32_t code, uint32_t flags,
    uint32_t nargs, uint64_t* args) {
    MW_TRACE("RaiseException(code=0x%x, flags=0x%x, nargs=%u)", code, flags, nargs);

    /* Build an EXCEPTION_RECORD on the stack */
    /* EXCEPTION_RECORD layout (x64):
     *   +0x00 ExceptionCode    (4)
     *   +0x04 ExceptionFlags   (4)
     *   +0x08 ExceptionRecord  (8, pointer)
     *   +0x10 ExceptionAddress (8, pointer)
     *   +0x18 NumberParameters(4)
     *   +0x1C __alignment    (4)
     *   +0x20 ExceptionInformation[0..14] (15 * 8 = 120)
     * Total: 0x98 bytes
     */
    uint8_t er_buf[0x100];
    memset(er_buf, 0, sizeof(er_buf));
    *(uint32_t*)(er_buf + 0x00) = code;
    *(uint32_t*)(er_buf + 0x04) = flags;
    *(uint64_t*)(er_buf + 0x08) = 0; /* no nested */
    *(uint64_t*)(er_buf + 0x10) = (uint64_t)(uintptr_t)__builtin_return_address(0);
    *(uint32_t*)(er_buf + 0x18) = nargs;
    if (nargs > 0 && args) {
        memcpy(er_buf + 0x20, args, nargs * 8);
    }

    /* EXCEPTION_POINTERS: { EXCEPTION_RECORD*, CONTEXT* } */
    uint64_t ep[2] = { (uint64_t)(uintptr_t)er_buf, 0 };

    /* 1. Try VEH handlers */
    for (int i = 0; i < g_veh_count; i++) {
        if (g_veh_handlers[i]) {
            typedef long (*veh_fn)(uint64_t* exception_pointers);
            veh_fn veh = (veh_fn)g_veh_handlers[i];
            long result = veh(ep);
            MW_TRACE("  VEH handler %p returned %ld", g_veh_handlers[i], result);
            if (result == -1) return; /* EXCEPTION_CONTINUE_EXECUTION */
        }
    }

    /* 2. Try to find frame-based handler via .pdata */
    uint64_t ret_addr = (uint64_t)(uintptr_t)__builtin_return_address(0);
    uint64_t rva = ret_addr - (uint64_t)(uintptr_t)g_image_base;

    /* Search .pdata for the function containing ret_addr */
    /* .pdata at RVA 0x1f8000, size 0x8e08 */
    uint32_t pdata_rva = 0x1f8000;
    uint32_t pdata_size = 0x8e08;
    int num_entries = pdata_size / 12; /* sizeof(RUNTIME_FUNCTION) = 12 */

    for (int i = 0; i < num_entries; i++) {
        uint32_t begin = *(uint32_t*)(g_image_base + pdata_rva + i * 12 + 0);
        uint32_t end   = *(uint32_t*)(g_image_base + pdata_rva + i * 12 + 4);
        uint32_t unwind= *(uint32_t*)(g_image_base + pdata_rva + i * 12 + 8);

        if (rva >= begin && rva < end) {
            MW_TRACE("  Found RUNTIME_FUNCTION: begin=0x%x end=0x%x unwind=0x%x",
                     begin, end, unwind);

            uint8_t* ui = g_image_base + unwind;
            uint8_t ui_flags = ui[1] & 0x1F;
            uint8_t ui_version = ui[0] & 0x07;
            uint8_t num_codes = ui[2];

            if (ui_flags & 0x01) { /* UNW_FLAG_EHANDLER */
                uint32_t handler_off = 4 + num_codes * 2;
                if (handler_off % 4) handler_off += 2;
                uint32_t handler_rva = *(uint32_t*)(ui + handler_off);
                MW_TRACE("  Exception handler at RVA 0x%x", handler_rva);

                /* Call __C_specific_handler or other handler */
                typedef long (*handler_fn)(uint8_t* er, void* establisher_frame,
                    uint8_t* ctx, void* dispatcher_ctx);
                handler_fn handler = (handler_fn)(g_image_base + handler_rva);

                /* Build a minimal context - just enough for __C_specific_handler */
                /* The handler needs to walk the __try/__except chain.
                 * For now, call with what we have. */
                long result = handler(er_buf, NULL, NULL, NULL);
                MW_TRACE("  Handler returned %ld", result);
                if (result == -1) return; /* EXCEPTION_CONTINUE_EXECUTION */
                if (result == 0) break;  /* EXCEPTION_CONTINUE_SEARCH */
            }
            break;
        }
    }

    /* 3. Last resort: UnhandledExceptionFilter */
    if (g_unhandled_exception_filter) {
        typedef long (*uef_fn)(uint64_t* exception_pointers);
        uef_fn uef = (uef_fn)g_unhandled_exception_filter;
        long result = uef(ep);
        MW_TRACE("  UnhandledExceptionFilter returned %ld", result);
        if (result == -1) return;
    }

    MW_TRACE("  Exception unhandled");
}

__attribute__((ms_abi)) int mw_ReleaseSemaphore(void* h, int32_t count, int32_t* prev) {
    MW_TRACE("ReleaseSemaphore()");
    if (prev) *prev = 0;
    return 1;
}

__attribute__((ms_abi)) int mw_ResetEvent(void* h) {
    MW_TRACE("ResetEvent()");
    return 1;
}

__attribute__((ms_abi)) uint32_t mw_ResumeThread(void* h) {
    MW_TRACE("ResumeThread()");
    return 0;
}

/* SEH/Exception stubs */
__attribute__((ms_abi)) void mw_RtlCaptureContext(void* ctx) {
    MW_TRACE("RtlCaptureContext()");
}

__attribute__((ms_abi)) void* mw_RtlLookupFunctionEntry(uint64_t addr, void* base, void* history) {
    MW_TRACE("RtlLookupFunctionEntry(addr=0x%lx)", addr);
    return NULL;
}

__attribute__((ms_abi)) void mw_RtlUnwindEx(void* target, void* frame, void* ctx, void* exc, void* history) {
    MW_TRACE("RtlUnwindEx()");
}

__attribute__((ms_abi)) int mw_RtlVirtualUnwind(uint32_t code, uint64_t addr, void* info,
    void* ctx, void* data, void* disp) {
    MW_TRACE("RtlVirtualUnwind()");
    return 0;
}

__attribute__((ms_abi)) int mw_ScrollConsoleScreenBufferA(void* h, void* sr, void* dr, void* coord, void* fill) {
    MW_TRACE("ScrollConsoleScreenBufferA()");
    return 0;
}

__attribute__((ms_abi)) int mw_SetEvent(void* h) {
    MW_TRACE("SetEvent()");
    return 1;
}

__attribute__((ms_abi)) int mw_SetFileTime(void* h, void* ct, void* at, void* wt) {
    MW_TRACE("SetFileTime()");
    return 0;
}

__attribute__((ms_abi)) void mw_SetLastError(uint32_t err) {
    g_last_error = err;
    MW_TRACE("SetLastError(%u)", err);
}

__attribute__((ms_abi)) int mw_SetProcessAffinityMask(void* h, uint64_t mask) {
    MW_TRACE("SetProcessAffinityMask()");
    return 1;
}

__attribute__((ms_abi)) int mw_SetThreadContext(void* h, void* ctx) {
    MW_TRACE("SetThreadContext()");
    return 0;
}

__attribute__((ms_abi)) int mw_SetThreadPriority(void* h, int prio) {
    MW_TRACE("SetThreadPriority()");
    return 1;
}

__attribute__((ms_abi)) void* mw_SetUnhandledExceptionFilter(void* handler) {
    MW_TRACE("SetUnhandledExceptionFilter(handler=%p)", handler);
    void* old = g_unhandled_exception_filter;
    g_unhandled_exception_filter = handler;
    return old;
}

__attribute__((ms_abi)) void mw_Sleep(uint32_t ms) {
    MW_TRACE("Sleep(%u)", ms);
    if (ms > 0) usleep((useconds_t)ms * 1000);
}

__attribute__((ms_abi)) uint32_t mw_SuspendThread(void* h) {
    MW_TRACE("SuspendThread()");
    return 0;
}

/* TLS */
static void* g_tls_values[64] = {0};

__attribute__((ms_abi)) uint32_t mw_TlsAlloc(void) {
    static uint32_t next = 0;
    uint32_t idx = next++;
    if (idx < 64) {
        MW_TRACE("TlsAlloc() = %u", idx);
        return idx;
    }
    return (uint32_t)(-1);
}

__attribute__((ms_abi)) void* mw_TlsGetValue(uint32_t idx) {
    void* val = (idx < 64) ? g_tls_values[idx] : NULL;
    MW_TRACE("TlsGetValue(%u) = %p", idx, val);
    return val;
}

__attribute__((ms_abi)) int mw_TlsSetValue(uint32_t idx, void* val) {
    if (idx < 64) g_tls_values[idx] = val;
    MW_TRACE("TlsSetValue(%u, %p)", idx, val);
    return 1;
}

__attribute__((ms_abi)) int mw_VirtualProtect(void* addr, size_t size, uint32_t prot, uint32_t* old) {
    MW_TRACE("VirtualProtect(addr=%p, size=0x%zx, prot=0x%x)", addr, size, prot);
    int linux_prot = PROT_READ | PROT_WRITE;
    if (prot & 0x01) linux_prot = PROT_READ;
    if (prot & 0x02) linux_prot |= PROT_READ;
    if (prot & 0x04) linux_prot |= PROT_WRITE;
    if (prot & 0x20) linux_prot |= PROT_EXEC;
    if (old) *old = 0x04; /* PAGE_READWRITE */
    /* For --version, VirtualProtect on our own mapped memory should work */
    if (mprotect(addr, size, linux_prot) == 0) return 1;
    return 0;
}

__attribute__((ms_abi)) size_t mw_VirtualQuery(void* addr, void* info, size_t len) {
    MW_TRACE("VirtualQuery(addr=%p)", addr);
    if (info && len >= 48) {
        memset(info, 0, 48);
        *(uint64_t*)((uint8_t*)info + 0) = (uint64_t)(uintptr_t)addr; /* BaseAddress */
        *(uint64_t*)((uint8_t*)info + 8) = 0x1000;                    /* AllocationBase */
        *(uint32_t*)((uint8_t*)info + 16) = 0x1000;                   /* AllocationProtect */
        *(uint64_t*)((uint8_t*)info + 24) = g_image_size;              /* RegionSize */
        *(uint32_t*)((uint8_t*)info + 32) = 0x04;                     /* State = MEM_COMMIT */
        *(uint32_t*)((uint8_t*)info + 36) = 0x40 | 0x20;             /* Protect = PAGE_READWRITE | RWX */
        *(uint32_t*)((uint8_t*)info + 40) = 0x1000;                   /* Type = MEM_PRIVATE */
        return 48;
    }
    return 0;
}

__attribute__((ms_abi)) uint32_t mw_WaitForSingleObject(void* h, uint32_t ms) {
    MW_TRACE("WaitForSingleObject(handle=%p, ms=%u)", h, ms);
    return 0; /* WAIT_OBJECT_0 */
}

__attribute__((ms_abi)) uint32_t mw_WaitForMultipleObjects(uint32_t count, void** handles,
    int all, uint32_t ms) {
    MW_TRACE("WaitForMultipleObjects(count=%u, all=%d, ms=%u)", count, all, ms);
    return 0; /* WAIT_OBJECT_0 */
}

__attribute__((ms_abi)) int mw_WideCharToMultiByte(uint32_t cp, uint32_t flags,
    const wchar_t* src, int srclen, char* dst, int dstlen, char* defc, int* used) {
    MW_TRACE("WideCharToMultiByte(cp=%u, srclen=%d, dstlen=%d)", cp, srclen, dstlen);
    if (!src) return 0;
    int wlen = srclen;
    if (wlen < 0) wlen = (int)wcslen(src);
    if (dstlen == 0) return wlen;
    int mlen = wcstombs(dst, src, dstlen);
    return (mlen < 0) ? 0 : mlen;
}

/* ============================================================
 * msvcrt.dll Stubs (ms_abi calling convention)
 * ============================================================ */

/* CRT Data pointers */
static char* g_acmdln_ptr = NULL;     /* pointer to ANSI command line */
static char** g_initenv_ptr = NULL;   /* pointer to env array */
static int  g_errno_storage = 0;   /* our errno mirror */
static int* g_errno_ptr = &g_errno_storage;

/* These are DATA imports - the IAT slot gets the ADDRESS of the data,
 * not a function pointer. Handled specially in import resolution. */

/* CRT init functions */
__attribute__((ms_abi)) void mw___set_app_type(int type) {
    g_app_type = type;
    MW_TRACE("__set_app_type(%d)", type);
}

__attribute__((ms_abi)) void mw___setusermatherr(void* handler) {
    MW_TRACE("__setusermatherr(handler=%p)", handler);
}

__attribute__((ms_abi)) int mw___getmainargs(int* pargc, char*** pargv, char*** penvp,
    int dowildcard, void* startup) {
    MW_TRACE("__getmainargs(argc=%p, argv=%p, envp=%p)", pargc, pargv, penvp);
    if (pargc) *pargc = g_argc;
    if (pargv) *pargv = g_argv;
    if (penvp) *penvp = g_initenv_ptr;
    return 0;
}

__attribute__((ms_abi)) int mw___lconv_init(void) {
    MW_TRACE("__lconv_init()");
    localeconv(); /* initialize locale data */
    return 0;
}

__attribute__((ms_abi)) int mw___C_specific_handler(void* exc, void* frame, void* ctx,
    void* disp, void* history) {
    MW_TRACE("__C_specific_handler()");
    return 0;
}

/* _initterm: walk a table of function pointers, call each non-NULL one.
 * The table is terminated by a NULL entry.
 * Returns the return value of the last non-NULL function called.
 */
__attribute__((ms_abi)) int mw__initterm(void** start, void** end) {
    MW_TRACE("_initterm(start=%p, end=%p)", start, end);
    int ret = 0;
    if (!start || !end) return 0;
    for (void** p = start; p < end; p++) {
        if (*p != NULL) {
            MW_TRACE("_initterm: calling %p", *p);
            /* Call the function pointer using ms_abi since these are
             * internal CRT functions compiled with MSVC */
            int (*fn)(void) = (int (*)(void))*p;
            ret = fn();
        }
    }
    return ret;
}

__attribute__((ms_abi)) void mw__amsg_exit(int msg) {
    MW_TRACE("_amsg_exit(msg=%d)", msg);
    fprintf(stderr, "Runtime Error: message id %d\n", msg);
    exit(255);
}

__attribute__((ms_abi)) void mw__cexit(void) {
    MW_TRACE("_cexit()");
    fflush(stdout);
    fflush(stderr);
}

__attribute__((ms_abi)) void* mw___iob_func(void) {
    /* Returns pointer to array of FILE* (stdin, stdout, stderr, ...) */
    static void* iob_array[3];
    iob_array[0] = stdin;
    iob_array[1] = stdout;
    iob_array[2] = stderr;
    MW_TRACE("__iob_func() = %p", iob_array);
    return iob_array;
}

/* Data accessor functions */
__attribute__((ms_abi)) unsigned int mw___lc_codepage_func(void) {
    MW_TRACE("__lc_codepage_func() = %u", 0);
    return 0; /* CP_ACP */
}

__attribute__((ms_abi)) int mw___mb_cur_max_func(void) {
    MW_TRACE("__mb_cur_max_func() = 1");
    return 1;
}

/* printf - variadic, needs special handling */
__attribute__((ms_abi)) int mw_printf(const char* fmt, ...) {
    MW_TRACE("printf(fmt=%s)", fmt ? fmt : "NULL");
    va_list ap;
    va_start(ap, fmt);
    int ret = vprintf(fmt, ap);
    va_end(ap);
    return ret;
}

/* fprintf - variadic */
__attribute__((ms_abi)) int mw_fprintf(void* file, const char* fmt, ...) {
    MW_TRACE("fprintf(file=%p, fmt=%s)", file, fmt ? fmt : "NULL");
    va_list ap;
    va_start(ap, fmt);
    /* Use actual FILE* if it's a real glibc FILE */
    FILE* f = (file == stdout || file == stderr || file == stdin) ? (FILE*)file : stdout;
    int ret = vfprintf(f, fmt, ap);
    va_end(ap);
    return ret;
}

/* vfprintf - the va_list is in MS ABI format */
__attribute__((ms_abi)) int mw_vfprintf(void* file, const char* fmt, void* ap) {
    MW_TRACE("vfprintf(file=%p, fmt=%s)", file, fmt ? fmt : "NULL");
    /* The ap argument is a pointer to ms_abi va_list.
     * Since ms_abi va_list is just a char* pointing to stack args,
     * and the first 4 args are in registers (already consumed by fmt),
     * the remaining args are on the stack.
     * For simple format strings (few args), this may work.
     * For complex cases, we'd need to rebuild the va_list.
     */
    FILE* f = (file == stdout || file == stderr || file == stdin) ? (FILE*)file : stdout;
    /* Use a workaround: format to buffer first */
    char buf[8192];
    int ret = vsnprintf(buf, sizeof(buf), fmt, *(va_list*)ap);
    if (ret > 0) {
        fwrite(buf, 1, ret, f);
    }
    return ret;
}

/* stdio stubs */
__attribute__((ms_abi)) int mw_fflush(void* file) {
    MW_TRACE("fflush(file=%p)", file);
    FILE* f = (file == NULL) ? NULL :
              (file == stdout || file == stderr || file == stdin) ? (FILE*)file : stdout;
    return fflush(f);
}

__attribute__((ms_abi)) int mw_fputs(const char* str, void* file) {
    MW_TRACE("fputs(str=%s)", str ? str : "NULL");
    FILE* f = (file == stdout || file == stderr || file == stdin) ? (FILE*)file : stdout;
    return fputs(str, f);
}

__attribute__((ms_abi)) int mw_fputc(int ch, void* file) {
    MW_TRACE("fputc(ch=0x%x)", ch);
    FILE* f = (file == stdout || file == stderr || file == stdin) ? (FILE*)file : stdout;
    return fputc(ch, f);
}

__attribute__((ms_abi)) size_t mw_fwrite(const void* buf, size_t sz, size_t cnt, void* file) {
    MW_TRACE("fwrite(sz=%zu, cnt=%zu)", sz, cnt);
    FILE* f = (file == stdout || file == stderr || file == stdin) ? (FILE*)file : stdout;
    return fwrite(buf, sz, cnt, f);
}

__attribute__((ms_abi)) int mw_getc(void* file) {
    MW_TRACE("getc()");
    return EOF;
}

__attribute__((ms_abi)) int mw_ungetc(int ch, void* file) {
    MW_TRACE("ungetc(ch=0x%x)", ch);
    return EOF;
}

__attribute__((ms_abi)) int mw_puts(const char* str) {
    MW_TRACE("puts(str=%s)", str ? str : "NULL");
    return puts(str);
}

/* Memory */
__attribute__((ms_abi)) void* mw_malloc(size_t size) {
    void* p = malloc(size);
    MW_TRACE("malloc(%zu) = %p", size, p);
    return p;
}

__attribute__((ms_abi)) void mw_free(void* ptr) {
    MW_TRACE("free(%p)", ptr);
    free(ptr);
}

__attribute__((ms_abi)) void* mw_realloc(void* ptr, size_t size) {
    void* p = realloc(ptr, size);
    MW_TRACE("realloc(%p, %zu) = %p", ptr, size, p);
    return p;
}

__attribute__((ms_abi)) void* mw_calloc(size_t n, size_t sz) {
    void* p = calloc(n, sz);
    MW_TRACE("calloc(%zu, %zu) = %p", n, sz, p);
    return p;
}

/* String functions */
__attribute__((ms_abi)) size_t mw_strlen(const char* s) {
    return strlen(s);
}
__attribute__((ms_abi)) int mw_strcmp(const char* a, const char* b) {
    return strcmp(a, b);
}
__attribute__((ms_abi)) char* mw_strcpy(char* d, const char* s) {
    return strcpy(d, s);
}
__attribute__((ms_abi)) char* mw_strchr(const char* s, int c) {
    return (char*)strchr(s, c);
}
__attribute__((ms_abi)) char* mw_strrchr(const char* s, int c) {
    return (char*)strrchr(s, c);
}
__attribute__((ms_abi)) char* mw_strstr(const char* h, const char* n) {
    return (char*)strstr(h, n);
}
__attribute__((ms_abi)) size_t mw_strcspn(const char* s, const char* r) {
    return strcspn(s, r);
}
__attribute__((ms_abi)) int mw_strncmp(const char* a, const char* b, size_t n) {
    return strncmp(a, b, n);
}
__attribute__((ms_abi)) int mw__stricmp(const char* a, const char* b) {
    return strcasecmp(a, b);
}
__attribute__((ms_abi)) char* mw__strdup(const char* s) {
    return strdup(s);
}
__attribute__((ms_abi)) void* mw_memchr(const void* s, int c, size_t n) {
    return (void*)memchr(s, c, n);
}
__attribute__((ms_abi)) int mw_memcmp(const void* a, const void* b, size_t n) {
    return memcmp(a, b, n);
}
__attribute__((ms_abi)) void* mw_memcpy(void* d, const void* s, size_t n) {
    return memcpy(d, s, n);
}
__attribute__((ms_abi)) void* mw_memmove(void* d, const void* s, size_t n) {
    return memmove(d, s, n);
}
__attribute__((ms_abi)) void* mw_memset(void* s, int c, size_t n) {
    return memset(s, c, n);
}

/* Conversion */
__attribute__((ms_abi)) int mw_atoi(const char* s) { return atoi(s); }

__attribute__((ms_abi)) long mw_strtol(const char* s, char** end, int base) {
    return strtol(s, end, base);
}

__attribute__((ms_abi)) unsigned long mw_strtoul(const char* s, char** end, int base) {
    return strtoul(s, end, base);
}

__attribute__((ms_abi)) char* mw__ultoa(unsigned long val, char* buf, int base) {
    unsigned long v = val;
    char tmp[33];
    int i = 0;
    if (v == 0) { buf[0] = '0'; buf[1] = 0; return buf; }
    while (v > 0) { tmp[i++] = "0123456789abcdef"[v % base]; v /= base; }
    int j = 0;
    while (i > 0) buf[j++] = tmp[--i];
    buf[j] = 0;
    return buf;
}

__attribute__((ms_abi)) int mw_tolower(int c) { return tolower(c); }
__attribute__((ms_abi)) size_t mw_wcstombs(char* d, const wchar_t* s, size_t n) {
    return wcstombs(d, s, n);
}
__attribute__((ms_abi)) size_t mw_wcslen(const wchar_t* s) { return wcslen(s); }

/* Character classification */
__attribute__((ms_abi)) int mw_islower(int c) { return islower(c); }
__attribute__((ms_abi)) int mw_isspace(int c) { return isspace(c); }
__attribute__((ms_abi)) int mw_isupper(int c) { return isupper(c); }
__attribute__((ms_abi)) int mw_isxdigit(int c) { return isxdigit(c); }

/* Time */
__attribute__((ms_abi)) clock_t mw_clock(void) { return clock(); }

/* File I/O - low level MSVCRT functions */
__attribute__((ms_abi)) int mw__open(const char* path, int flags, ...) {
    MW_TRACE("_open(path=%s, flags=0x%x)", path ? path : "NULL", flags);
    int mode = 0;
    va_list ap;
    va_start(ap, flags);
    if (flags & 0x0100) mode = va_arg(ap, int); /* _O_CREAT */
    va_end(ap);
    /* Map MSVC flags to POSIX */
    int oflags = ((flags & 0x0003) == 0) ? O_RDONLY : 0;
    if (flags & 0x0001) oflags = O_WRONLY;
    if (flags & 0x0002) oflags = O_RDWR;
    if (flags & 0x0080) oflags |= O_APPEND;
    if (flags & 0x0100) oflags |= O_CREAT;
    if (flags & 0x0200) oflags |= O_TRUNC;
    if (flags & 0x0400) oflags |= O_EXCL;
    /* _O_TEXT (0x4000) and _O_BINARY (0x8000) ignored on Linux */
    int fd = open(path, oflags, mode);
    return fd;
}

__attribute__((ms_abi)) int mw__read(int fd, void* buf, unsigned int cnt) {
    MW_TRACE("_read(fd=%d, cnt=%u)", fd, cnt);
    return (int)read(fd, buf, cnt);
}

__attribute__((ms_abi)) int mw__write(int fd, const void* buf, unsigned int cnt) {
    MW_TRACE("_write(fd=%d, cnt=%u)", fd, cnt);
    int ret = (int)write(fd, buf, cnt);
    return ret;
}

__attribute__((ms_abi)) int mw__close(int fd) {
    MW_TRACE("_close(fd=%d)", fd);
    return close(fd);
}

__attribute__((ms_abi)) int mw__dup(int fd) {
    MW_TRACE("_dup(fd=%d)", fd);
    return dup(fd);
}

__attribute__((ms_abi)) int mw__isatty(int fd) {
    MW_TRACE("_isatty(fd=%d)", fd);
    return isatty(fd);
}

__attribute__((ms_abi)) int mw__fileno(void* file) {
    MW_TRACE("_fileno(file=%p)", file);
    if (file == stdin) return 0;
    if (file == stdout) return 1;
    if (file == stderr) return 2;
    return -1;
}

__attribute__((ms_abi)) int64_t mw__get_osfhandle(int fd) {
    MW_TRACE("_get_osfhandle(fd=%d)", fd);
    return (int64_t)(uintptr_t)fd;
}

__attribute__((ms_abi)) int mw__setmode(int fd, int mode) {
    MW_TRACE("_setmode(fd=%d, mode=%d)", fd, mode);
    return 0;
}

__attribute__((ms_abi)) int mw__sopen(const char* path, int flags, int shflag, int pmode) {
    MW_TRACE("_sopen(path=%s, flags=0x%x)", path ? path : "NULL", flags);
    return mw__open(path, flags, pmode);
}

__attribute__((ms_abi)) int mw__wopen(const wchar_t* path, int flags, ...) {
    MW_TRACE("_wopen()");
    char buf[1024];
    wcstombs(buf, path, sizeof(buf));
    return mw__open(buf, flags, 0);
}

/* stat */
#include <sys/types.h>
#include <sys/stat.h>

__attribute__((ms_abi)) int mw__fstat64(int fd, void* st) {
    MW_TRACE("_fstat64(fd=%d)", fd);
    struct stat64 st64;
    int ret = fstat64(fd, &st64);
    if (ret == 0 && st) {
        /* Map to MSVC _stat64 structure */
        memset(st, 0, 128);
        *(uint32_t*)((uint8_t*)st + 0) = st64.st_mode;
        *(int64_t*)((uint8_t*)st + 8) = st64.st_size;
        *(int64_t*)((uint8_t*)st + 24) = st64.st_atime;
        *(int64_t*)((uint8_t*)st + 32) = st64.st_mtime;
        *(int64_t*)((uint8_t*)st + 40) = st64.st_ctime;
    }
    return ret;
}

__attribute__((ms_abi)) int mw__stat64(const char* path, void* st) {
    MW_TRACE("_stat64(path=%s)", path ? path : "NULL");
    struct stat64 st64;
    int ret = stat64(path, &st64);
    if (ret == 0 && st) {
        memset(st, 0, 128);
        *(uint32_t*)((uint8_t*)st + 0) = st64.st_mode;
        *(int64_t*)((uint8_t*)st + 8) = st64.st_size;
        *(int64_t*)((uint8_t*)st + 24) = st64.st_atime;
        *(int64_t*)((uint8_t*)st + 32) = st64.st_mtime;
        *(int64_t*)((uint8_t*)st + 40) = st64.st_ctime;
    }
    return ret;
}

__attribute__((ms_abi)) int64_t mw__lseeki64(int fd, int64_t off, int whence) {
    MW_TRACE("_lseeki64(fd=%d, off=%ld, whence=%d)", fd, (long)off, whence);
    return lseek64(fd, off, whence);
}

__attribute__((ms_abi)) int mw_rename(const char* old, const char* new) {
    MW_TRACE("rename(old=%s, new=%s)", old, new);
    return rename(old, new);
}

__attribute__((ms_abi)) int mw__unlink(const char* path) {
    MW_TRACE("_unlink(path=%s)", path ? path : "NULL");
    return unlink(path);
}

__attribute__((ms_abi)) int mw__rmdir(const char* path) {
    MW_TRACE("_rmdir(path=%s)", path ? path : "NULL");
    return rmdir(path);
}

__attribute__((ms_abi)) int mw__chmod(const char* path, int mode) {
    MW_TRACE("_chmod(path=%s, mode=%d)", path ? path : "NULL", mode);
    return chmod(path, mode);
}

/* Time functions */
__attribute__((ms_abi)) time_t mw__time64(time_t* t) {
    return time(t);
}

__attribute__((ms_abi)) void* mw__gmtime64(const time_t* t) {
    return (void*)gmtime(t);
}

__attribute__((ms_abi)) void* mw__localtime64(const time_t* t) {
    return (void*)localtime(t);
}

/* Misc */
__attribute__((ms_abi)) void mw_exit(int code) {
    MW_TRACE("exit(%d)", code);
    fflush(stdout);
    fflush(stderr);
    exit(code);
}

__attribute__((ms_abi)) void mw_abort(void) {
    MW_TRACE("abort()");
    abort();
}

__attribute__((ms_abi)) void (*mw_signal(int sig, void (*handler)(int)))(int) {
    MW_TRACE("signal(sig=%d)", sig);
    return signal(sig, handler);
}

__attribute__((ms_abi)) void mw_longjmp(void* buf, int val) {
    MW_TRACE("longjmp(val=%d)", val);
    /* jmp_buf on glibc is struct __jmp_buf_tag[1] */
    siglongjmp(*(sigjmp_buf*)buf, val);
}

__attribute__((ms_abi)) int mw__setjmp(void* buf) {
    MW_TRACE("_setjmp()");
    return sigsetjmp(*(sigjmp_buf*)buf, 0);
}

__attribute__((ms_abi)) int mw__kbhit(void) { return 0; }

__attribute__((ms_abi)) char* mw_getenv(const char* name) {
    return getenv(name);
}

__attribute__((ms_abi)) void* mw_localeconv(void) {
    return (void*)localeconv();
}

__attribute__((ms_abi)) void mw_qsort(void* base, size_t n, size_t sz, int (*cmp)(const void*, const void*)) {
    qsort(base, n, sz, cmp);
}

__attribute__((ms_abi)) int mw_rand(void) { return rand(); }
__attribute__((ms_abi)) void mw_srand(unsigned int seed) { srand(seed); }

__attribute__((ms_abi)) int mw__onexit(void (*func)(void)) {
    MW_TRACE("_onexit(func=%p)", func);
    return atexit(func);
}

__attribute__((ms_abi)) unsigned long mw__beginthreadex(void* sec, unsigned int stk,
    void* (*start)(void*), void* arg, int init, unsigned int* tid) {
    MW_TRACE("_beginthreadex()");
    if (tid) *tid = 5678;
    return 0;
}

__attribute__((ms_abi)) void mw__endthreadex(unsigned int code) {
    MW_TRACE("_endthreadex(%u)", code);
    pthread_exit((void*)(uintptr_t)code);
}

__attribute__((ms_abi)) void mw__lock(int locknum) {
    MW_TRACE("_lock(%d)", locknum);
}

__attribute__((ms_abi)) void mw__unlock(int locknum) {
    MW_TRACE("_unlock(%d)", locknum);
}

/* ============================================================
 * Import Dispatch Table
 * Maps import name → function pointer (for code imports)
 * Data imports are handled separately.
 * ============================================================ */

typedef struct {
    const char* dll;
    const char* name;
    void*       func;  /* For code imports: ms_abi function pointer */
    int         is_data;
} ImportEntry;

#define ENTRY(dll, name, func) { dll, name, (void*)func, 0 }
#define DATA_ENTRY(dll, name, addr) { dll, name, (void*)addr, 1 }

static ImportEntry g_import_table[] = {
    /* KERNEL32.DLL */
    ENTRY("KERNEL32.DLL", "AddVectoredExceptionHandler",        mw_AddVectoredExceptionHandler),
    ENTRY("KERNEL32.DLL", "CloseHandle",                        mw_CloseHandle),
    ENTRY("KERNEL32.DLL", "CreateEventA",                       mw_CreateEventA),
    ENTRY("KERNEL32.DLL", "CreateSemaphoreA",                   mw_CreateSemaphoreA),
    ENTRY("KERNEL32.DLL", "DebugBreak",                         mw_DebugBreak),
    ENTRY("KERNEL32.DLL", "DeleteCriticalSection",              mw_DeleteCriticalSection),
    ENTRY("KERNEL32.DLL", "DuplicateHandle",                    mw_DuplicateHandle),
    ENTRY("KERNEL32.DLL", "EnterCriticalSection",               mw_EnterCriticalSection),
    ENTRY("KERNEL32.DLL", "GetConsoleCursorInfo",               mw_GetConsoleCursorInfo),
    ENTRY("KERNEL32.DLL", "GetConsoleMode",                      mw_GetConsoleMode),
    ENTRY("KERNEL32.DLL", "GetConsoleScreenBufferInfo",          mw_GetConsoleScreenBufferInfo),
    ENTRY("KERNEL32.DLL", "GetCurrentProcess",                   mw_GetCurrentProcess),
    ENTRY("KERNEL32.DLL", "GetCurrentProcessId",                 mw_GetCurrentProcessId),
    ENTRY("KERNEL32.DLL", "GetCurrentThread",                   mw_GetCurrentThread),
    ENTRY("KERNEL32.DLL", "GetCurrentThreadId",                 mw_GetCurrentThreadId),
    ENTRY("KERNEL32.DLL", "GetFileTime",                         mw_GetFileTime),
    ENTRY("KERNEL32.DLL", "GetHandleInformation",               mw_GetHandleInformation),
    ENTRY("KERNEL32.DLL", "GetLastError",                        mw_GetLastError),
    ENTRY("KERNEL32.DLL", "GetModuleHandleA",                    mw_GetModuleHandleA),
    ENTRY("KERNEL32.DLL", "GetProcAddress",                      mw_GetProcAddress),
    ENTRY("KERNEL32.DLL", "GetProcessAffinityMask",             mw_GetProcessAffinityMask),
    ENTRY("KERNEL32.DLL", "GetStartupInfoA",                     mw_GetStartupInfoA),
    ENTRY("KERNEL32.DLL", "GetStdHandle",                       mw_GetStdHandle),
    ENTRY("KERNEL32.DLL", "GetSystemTimeAsFileTime",             mw_GetSystemTimeAsFileTime),
    ENTRY("KERNEL32.DLL", "GetThreadContext",                    mw_GetThreadContext),
    ENTRY("KERNEL32.DLL", "GetThreadPriority",                   mw_GetThreadPriority),
    ENTRY("KERNEL32.DLL", "GetTickCount",                        mw_GetTickCount),
    ENTRY("KERNEL32.DLL", "InitializeCriticalSection",           mw_InitializeCriticalSection),
    ENTRY("KERNEL32.DLL", "IsDBCSLeadByteEx",                    mw_IsDBCSLeadByteEx),
    ENTRY("KERNEL32.DLL", "IsDebuggerPresent",                   mw_IsDebuggerPresent),
    ENTRY("KERNEL32.DLL", "LeaveCriticalSection",               mw_LeaveCriticalSection),
    ENTRY("KERNEL32.DLL", "MultiByteToWideChar",                 mw_MultiByteToWideChar),
    ENTRY("KERNEL32.DLL", "OpenProcess",                         mw_OpenProcess),
    ENTRY("KERNEL32.DLL", "OutputDebugStringA",                  mw_OutputDebugStringA),
    ENTRY("KERNEL32.DLL", "QueryPerformanceCounter",             mw_QueryPerformanceCounter),
    ENTRY("KERNEL32.DLL", "QueryPerformanceFrequency",           mw_QueryPerformanceFrequency),
    ENTRY("KERNEL32.DLL", "RaiseException",                      mw_RaiseException),
    ENTRY("KERNEL32.DLL", "ReleaseSemaphore",                    mw_ReleaseSemaphore),
    ENTRY("KERNEL32.DLL", "RemoveVectoredExceptionHandler",       mw_RemoveVectoredExceptionHandler),
    ENTRY("KERNEL32.DLL", "ResetEvent",                          mw_ResetEvent),
    ENTRY("KERNEL32.DLL", "ResumeThread",                        mw_ResumeThread),
    ENTRY("KERNEL32.DLL", "RtlCaptureContext",                   mw_RtlCaptureContext),
    ENTRY("KERNEL32.DLL", "RtlLookupFunctionEntry",              mw_RtlLookupFunctionEntry),
    ENTRY("KERNEL32.DLL", "RtlUnwindEx",                         mw_RtlUnwindEx),
    ENTRY("KERNEL32.DLL", "RtlVirtualUnwind",                    mw_RtlVirtualUnwind),
    ENTRY("KERNEL32.DLL", "ScrollConsoleScreenBufferA",          mw_ScrollConsoleScreenBufferA),
    ENTRY("KERNEL32.DLL", "SetConsoleCursorInfo",                mw_SetConsoleCursorInfo),
    ENTRY("KERNEL32.DLL", "SetConsoleCursorPosition",            mw_SetConsoleCursorPosition),
    ENTRY("KERNEL32.DLL", "SetConsoleTextAttribute",             mw_SetConsoleTextAttribute),
    ENTRY("KERNEL32.DLL", "SetEvent",                            mw_SetEvent),
    ENTRY("KERNEL32.DLL", "SetFileTime",                         mw_SetFileTime),
    ENTRY("KERNEL32.DLL", "SetLastError",                        mw_SetLastError),
    ENTRY("KERNEL32.DLL", "SetProcessAffinityMask",              mw_SetProcessAffinityMask),
    ENTRY("KERNEL32.DLL", "SetThreadContext",                    mw_SetThreadContext),
    ENTRY("KERNEL32.DLL", "SetThreadPriority",                   mw_SetThreadPriority),
    ENTRY("KERNEL32.DLL", "SetUnhandledExceptionFilter",         mw_SetUnhandledExceptionFilter),
    ENTRY("KERNEL32.DLL", "Sleep",                               mw_Sleep),
    ENTRY("KERNEL32.DLL", "SuspendThread",                       mw_SuspendThread),
    ENTRY("KERNEL32.DLL", "TlsAlloc",                            mw_TlsAlloc),
    ENTRY("KERNEL32.DLL", "TlsGetValue",                         mw_TlsGetValue),
    ENTRY("KERNEL32.DLL", "TlsSetValue",                         mw_TlsSetValue),
    ENTRY("KERNEL32.DLL", "TryEnterCriticalSection",             mw_TryEnterCriticalSection),
    ENTRY("KERNEL32.DLL", "VirtualProtect",                      mw_VirtualProtect),
    ENTRY("KERNEL32.DLL", "VirtualQuery",                        mw_VirtualQuery),
    ENTRY("KERNEL32.DLL", "WaitForMultipleObjects",              mw_WaitForMultipleObjects),
    ENTRY("KERNEL32.DLL", "WaitForSingleObject",                 mw_WaitForSingleObject),
    ENTRY("KERNEL32.DLL", "WideCharToMultiByte",                 mw_WideCharToMultiByte),
    ENTRY("KERNEL32.DLL", "WriteConsoleOutputA",                 mw_WriteConsoleOutputA),

    /* msvcrt.dll — Code imports */
    ENTRY("msvcrt.dll", "__C_specific_handler",   mw___C_specific_handler),
    ENTRY("msvcrt.dll", "__getmainargs",         mw___getmainargs),
    ENTRY("msvcrt.dll", "__iob_func",            mw___iob_func),
    ENTRY("msvcrt.dll", "__lconv_init",          mw___lconv_init),
    ENTRY("msvcrt.dll", "___lc_codepage_func",    mw___lc_codepage_func),
    ENTRY("msvcrt.dll", "___mb_cur_max_func",     mw___mb_cur_max_func),
    ENTRY("msvcrt.dll", "__set_app_type",        mw___set_app_type),
    ENTRY("msvcrt.dll", "__setusermatherr",      mw___setusermatherr),
    ENTRY("msvcrt.dll", "_amsg_exit",            mw__amsg_exit),
    ENTRY("msvcrt.dll", "_beginthreadex",        mw__beginthreadex),
    ENTRY("msvcrt.dll", "_cexit",                mw__cexit),
    ENTRY("msvcrt.dll", "_chmod",                mw__chmod),
    ENTRY("msvcrt.dll", "_close",                mw__close),
    ENTRY("msvcrt.dll", "_dup",                  mw__dup),
    ENTRY("msvcrt.dll", "_endthreadex",          mw__endthreadex),
    ENTRY("msvcrt.dll", "_fstat64",              mw__fstat64),
    ENTRY("msvcrt.dll", "_fileno",               mw__fileno),
    ENTRY("msvcrt.dll", "_get_osfhandle",        mw__get_osfhandle),
    ENTRY("msvcrt.dll", "_gmtime64",             mw__gmtime64),
    ENTRY("msvcrt.dll", "_initterm",             mw__initterm),
    ENTRY("msvcrt.dll", "_isatty",               mw__isatty),
    ENTRY("msvcrt.dll", "_kbhit",                mw__kbhit),
    ENTRY("msvcrt.dll", "_localtime64",          mw__localtime64),
    ENTRY("msvcrt.dll", "_lock",                 mw__lock),
    ENTRY("msvcrt.dll", "_lseeki64",             mw__lseeki64),
    ENTRY("msvcrt.dll", "_onexit",               mw__onexit),
    ENTRY("msvcrt.dll", "_open",                 mw__open),
    ENTRY("msvcrt.dll", "_read",                 mw__read),
    ENTRY("msvcrt.dll", "_rename",               mw_rename),
    ENTRY("msvcrt.dll", "_rmdir",                mw__rmdir),
    ENTRY("msvcrt.dll", "_sopen",                mw__sopen),
    ENTRY("msvcrt.dll", "_setmode",              mw__setmode),
    ENTRY("msvcrt.dll", "_setjmp",               mw__setjmp),
    ENTRY("msvcrt.dll", "_stat64",               mw__stat64),
    ENTRY("msvcrt.dll", "_strdup",               mw__strdup),
    ENTRY("msvcrt.dll", "_stricmp",              mw__stricmp),
    ENTRY("msvcrt.dll", "_time64",               mw__time64),
    ENTRY("msvcrt.dll", "_ultoa",                mw__ultoa),
    ENTRY("msvcrt.dll", "_unlink",               mw__unlink),
    ENTRY("msvcrt.dll", "_unlock",               mw__unlock),
    ENTRY("msvcrt.dll", "_wopen",                mw__wopen),
    ENTRY("msvcrt.dll", "_write",                mw__write),
    ENTRY("msvcrt.dll", "abort",                 mw_abort),
    ENTRY("msvcrt.dll", "atoi",                  mw_atoi),
    ENTRY("msvcrt.dll", "calloc",                mw_calloc),
    ENTRY("msvcrt.dll", "clock",                 mw_clock),
    ENTRY("msvcrt.dll", "exit",                  mw_exit),
    ENTRY("msvcrt.dll", "fflush",                mw_fflush),
    ENTRY("msvcrt.dll", "fprintf",               mw_fprintf),
    ENTRY("msvcrt.dll", "fputc",                 mw_fputc),
    ENTRY("msvcrt.dll", "fputs",                 mw_fputs),
    ENTRY("msvcrt.dll", "free",                  mw_free),
    ENTRY("msvcrt.dll", "fwrite",                mw_fwrite),
    ENTRY("msvcrt.dll", "getc",                  mw_getc),
    ENTRY("msvcrt.dll", "getenv",                mw_getenv),
    ENTRY("msvcrt.dll", "islower",               mw_islower),
    ENTRY("msvcrt.dll", "isspace",               mw_isspace),
    ENTRY("msvcrt.dll", "isupper",               mw_isupper),
    ENTRY("msvcrt.dll", "isxdigit",              mw_isxdigit),
    ENTRY("msvcrt.dll", "localeconv",            mw_localeconv),
    ENTRY("msvcrt.dll", "longjmp",               mw_longjmp),
    ENTRY("msvcrt.dll", "malloc",                mw_malloc),
    ENTRY("msvcrt.dll", "memchr",                mw_memchr),
    ENTRY("msvcrt.dll", "memcmp",                mw_memcmp),
    ENTRY("msvcrt.dll", "memcpy",                mw_memcpy),
    ENTRY("msvcrt.dll", "memmove",               mw_memmove),
    ENTRY("msvcrt.dll", "memset",                mw_memset),
    ENTRY("msvcrt.dll", "printf",                mw_printf),
    ENTRY("msvcrt.dll", "puts",                  mw_puts),
    ENTRY("msvcrt.dll", "qsort",                 mw_qsort),
    ENTRY("msvcrt.dll", "rand",                  mw_rand),
    ENTRY("msvcrt.dll", "realloc",               mw_realloc),
    ENTRY("msvcrt.dll", "rename",                mw_rename),
    ENTRY("msvcrt.dll", "signal",                mw_signal),
    ENTRY("msvcrt.dll", "srand",                 mw_srand),
    ENTRY("msvcrt.dll", "strchr",                mw_strchr),
    ENTRY("msvcrt.dll", "strcmp",                mw_strcmp),
    ENTRY("msvcrt.dll", "strcpy",                mw_strcpy),
    ENTRY("msvcrt.dll", "strcspn",               mw_strcspn),
    ENTRY("msvcrt.dll", "strerror",              (void*)strerror),
    ENTRY("msvcrt.dll", "strlen",                mw_strlen),
    ENTRY("msvcrt.dll", "strncmp",               mw_strncmp),
    ENTRY("msvcrt.dll", "strrchr",               mw_strrchr),
    ENTRY("msvcrt.dll", "strstr",                mw_strstr),
    ENTRY("msvcrt.dll", "strtol",                mw_strtol),
    ENTRY("msvcrt.dll", "strtoul",               mw_strtoul),
    ENTRY("msvcrt.dll", "tolower",               mw_tolower),
    ENTRY("msvcrt.dll", "ungetc",                mw_ungetc),
    ENTRY("msvcrt.dll", "vfprintf",              mw_vfprintf),
    ENTRY("msvcrt.dll", "wcstombs",               mw_wcstombs),
    ENTRY("msvcrt.dll", "wcslen",                mw_wcslen),
};

#define NUM_IMPORTS (sizeof(g_import_table) / sizeof(g_import_table[0]))

/* Data imports - resolved separately (IAT slot = address of data) */
typedef struct {
    const char* dll;
    const char* name;
    void*       data_addr; /* pointer to the actual data */
} DataImportEntry;

static DataImportEntry g_data_imports[] = {
    { "msvcrt.dll", "_acmdln",    &g_acmdln_ptr },
    { "msvcrt.dll", "__initenv",   &g_initenv_ptr },
    { "msvcrt.dll", "_commode",   &g_commode_val },
    { "msvcrt.dll", "_fmode",     &g_fmode_val },
    { "msvcrt.dll", "_errno",     &g_errno_ptr },
};
#define NUM_DATA_IMPORTS (sizeof(g_data_imports) / sizeof(g_data_imports[0]))

/* ============================================================
 * PE Loading
 * ============================================================ */

static int load_pe(const char* filepath) {
    FILE* f = fopen(filepath, "rb");
    if (!f) { fprintf(stderr, "[ERROR] Cannot open %s\n", filepath); return -1; }

    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    uint8_t* filedata = (uint8_t*)malloc(fsize);
    fread(filedata, 1, fsize, f);
    fclose(f);

    MW_TRACE("PE Loader: file=%s size=%ld", filepath, fsize);

    /* Parse DOS header */
    DosHeader* dos = (DosHeader*)filedata;
    if (dos->e_magic[0] != 'M' || dos->e_magic[1] != 'Z') {
        fprintf(stderr, "[ERROR] Not a valid PE file (bad DOS magic)\n");
        free(filedata);
        return -1;
    }

    uint32_t pe_off = dos->e_lfanew;
    uint8_t* pe_sig = filedata + pe_off;
    if (pe_sig[0] != 'P' || pe_sig[1] != 'E' || pe_sig[2] != 0 || pe_sig[3] != 0) {
        fprintf(stderr, "[ERROR] Not a valid PE file (bad PE signature)\n");
        free(filedata);
        return -1;
    }

    CoffHeader* coff = (CoffHeader*)(filedata + pe_off + 4);
    PeOptHeader64* opt = (PeOptHeader64*)(filedata + pe_off + 4 + sizeof(CoffHeader));

    if (opt->Magic != PE32PLUS_MAGIC) {
        fprintf(stderr, "[ERROR] Not a PE32+ file (magic=0x%x)\n", opt->Magic);
        free(filedata);
        return -1;
    }

    g_entry_point = (uint64_t)opt->AddressOfEntryPoint;
    uint64_t image_base = opt->ImageBase;
    uint32_t size_of_image = opt->SizeOfImage;
    uint32_t section_align = opt->SectionAlignment;
    uint32_t num_sections = coff->NumberOfSections;
    uint32_t num_dd = opt->NumberOfRvaAndSizes;

    MW_TRACE("PE Loader: ImageBase=0x%lx EP=0x%lx SizeOfImage=0x%x Sections=%u",
             (unsigned long)image_base, (unsigned long)g_entry_point, size_of_image, num_sections);

    /* Allocate image at ImageBase */
    g_image_base = (uint8_t*)mmap((void*)(uintptr_t)image_base, size_of_image,
        PROT_READ | PROT_WRITE | PROT_EXEC,
        MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);

    if (g_image_base == MAP_FAILED) {
        /* Try without MAP_FIXED_NOREPLACE — map anywhere */
        MW_TRACE("PE Loader: Cannot map at 0x%lx, trying any address", image_base);
        g_image_base = (uint8_t*)mmap(NULL, size_of_image,
            PROT_READ | PROT_WRITE | PROT_EXEC,
            MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (g_image_base == MAP_FAILED) {
            fprintf(stderr, "[ERROR] Cannot mmap %u bytes\n", size_of_image);
            free(filedata);
            return -1;
        }
        MW_TRACE("PE Loader: Mapped at %p instead of 0x%lx", g_image_base, image_base);
    } else {
        MW_TRACE("PE Loader: Mapped at 0x%lx (requested)", image_base);
    }
    g_image_size = size_of_image;

    /* Copy headers */
    memcpy(g_image_base, filedata, opt->SizeOfHeaders);

    /* Map sections */
    uint32_t opt_hdr_size = coff->SizeOfOptionalHeader;
    SectionHeader* sections = (SectionHeader*)(filedata + pe_off + 4 + sizeof(CoffHeader) + opt_hdr_size);

    for (uint32_t i = 0; i < num_sections; i++) {
        SectionHeader* sec = &sections[i];
        if (sec->SizeOfRawData > 0) {
            memcpy(g_image_base + sec->VirtualAddress,
                   filedata + sec->PointerToRawData,
                   sec->SizeOfRawData);
        }
        /* Zero BSS */
        if (sec->VirtualSize > sec->SizeOfRawData) {
            memset(g_image_base + sec->VirtualAddress + sec->SizeOfRawData, 0,
                   sec->VirtualSize - sec->SizeOfRawData);
        }

        char sec_name[9] = {0};
        memcpy(sec_name, sec->Name, 8);
        MW_TRACE("Section [%u] %-8s VA=0x%08x VS=0x%08x Raw=0x%08x Ch=0x%08x",
                 i, sec_name, sec->VirtualAddress, sec->VirtualSize,
                 sec->SizeOfRawData, sec->Characteristics);

        /* Set section permissions */
        int prot = PROT_READ;
        if (sec->Characteristics & SCN_MEM_EXECUTE) prot |= PROT_EXEC;
        if (sec->Characteristics & SCN_MEM_WRITE)   prot |= PROT_WRITE;
        if (sec->Characteristics & SCN_MEM_READ)    prot |= PROT_READ;
        mprotect(g_image_base + sec->VirtualAddress,
                 (sec->VirtualSize + section_align - 1) & ~(section_align - 1), prot);
    }

    /* Parse and resolve imports */
    /* DataDirectory starts at offset 112 within the optional header */
    uint32_t dd_offset = pe_off + 4 + sizeof(CoffHeader) + 112;
    DataDirectory* dd = (DataDirectory*)(filedata + dd_offset);

    uint32_t import_rva = dd[DD_IMPORT].VirtualAddress;
    uint32_t import_size = dd[DD_IMPORT].Size;

    if (import_rva == 0) {
        fprintf(stderr, "[ERROR] No import directory\n");
        free(filedata);
        return -1;
    }

    MW_TRACE("Import Directory: RVA=0x%x Size=0x%x", import_rva, import_size);

    /* Walk import directory */
    int import_idx = 0;
    int total_resolved = 0;
    int total_unresolved = 0;

    for (uint32_t imp_idx = 0; ; imp_idx++) {
        ImportDirectoryEntry* imp = (ImportDirectoryEntry*)(g_image_base + import_rva + imp_idx * 20);
        if (imp->Name == 0 && imp->FirstThunk == 0) break;

        const char* dll_name = (const char*)(g_image_base + imp->Name);
        uint32_t ilt_rva = imp->OriginalFirstThunk;
        uint32_t iat_off = imp->FirstThunk;

        MW_TRACE("Import DLL: %s (IAT RVA=0x%x, ILT RVA=0x%x)", dll_name, iat_off, ilt_rva);

        /* Walk IAT/ILT entries */
        uint32_t lookup_rva = ilt_rva ? ilt_rva : iat_off;
        int slot = 0;

        for (;;) {
            uint64_t entry = *(uint64_t*)(g_image_base + lookup_rva + slot * 8);
            if (entry == 0) break;

            const char* func_name = NULL;
            uint16_t hint = 0;

            if (!(entry & 0x8000000000000000ULL)) {
                /* Import by name */
                uint32_t name_rva = (uint32_t)(entry & 0x7FFFFFFF);
                hint = *(uint16_t*)(g_image_base + name_rva);
                func_name = (const char*)(g_image_base + name_rva + 2);
            } else {
                /* Import by ordinal */
                uint16_t ordinal = (uint16_t)(entry & 0xFFFF);
                MW_TRACE("  [%d] Ordinal %u (not supported)", slot, ordinal);
                total_unresolved++;
                slot++;
                continue;
            }

            /* Search our dispatch table */
            int found = 0;
            for (size_t t = 0; t < NUM_IMPORTS; t++) {
                if (strcmp(g_import_table[t].name, func_name) == 0) {
                    /* Found! Patch IAT */
                    void* patch_addr = g_image_base + iat_off + slot * 8;
                    *(uint64_t*)patch_addr = (uint64_t)(uintptr_t)g_import_table[t].func;
                    found = 1;
                    total_resolved++;
                    break;
                }
            }

            /* Check data imports */
            if (!found) {
                for (size_t t = 0; t < NUM_DATA_IMPORTS; t++) {
                    if (strcmp(g_data_imports[t].name, func_name) == 0) {
                        void* patch_addr = g_image_base + iat_off + slot * 8;
                        *(uint64_t*)patch_addr = (uint64_t)(uintptr_t)g_data_imports[t].data_addr;
                        found = 1;
                        total_resolved++;
                        MW_TRACE("  [%d] %s -> DATA %p", slot, func_name, g_data_imports[t].data_addr);
                        break;
                    }
                }
            }

            if (!found) {
                MW_TRACE("  [%d] UNRESOLVED: %s", slot, func_name);
                total_unresolved++;
            } else {
                /* Only log code imports here (data imports logged above) */
                int is_data = 0;
                for (size_t t = 0; t < NUM_DATA_IMPORTS; t++) {
                    if (strcmp(g_data_imports[t].name, func_name) == 0) { is_data = 1; break; }
                }
                if (!is_data) {
                    void* resolved = (void*)*(uint64_t*)(g_image_base + iat_off + slot * 8);
                    MW_TRACE("  [%d] %s -> %p", slot, func_name, resolved);
                }
            }

            slot++;
            import_idx++;
        }
    }

    MW_TRACE("Import resolution: %d resolved, %d unresolved (total %d)",
             total_resolved, total_unresolved, total_resolved + total_unresolved);

    if (total_unresolved > 0) {
        fprintf(stderr, "[WARN] %d imports unresolved\n", total_unresolved);
    }

    /* Check TLS */
    if (num_dd > DD_TLS && dd[DD_TLS].VirtualAddress != 0) {
        TlsDirectory64* tls = (TlsDirectory64*)(g_image_base + dd[DD_TLS].VirtualAddress);
        MW_TRACE("TLS: StartRaw=0x%lx EndRaw=0x%lx Callbacks=0x%lx",
                 tls->StartAddressOfRawData, tls->EndAddressOfRawData,
                 tls->AddressOfCallBacks);
        /* No TLS callbacks for UPX 4.2.4 (AddressOfCallBacks = 0) */
    }

    free(filedata);
    return 0;
}

/* ============================================================
 * Signal Handler (for debugging crashes)
 * ============================================================ */

static void crash_handler(int sig, siginfo_t* info, void* ctx) {
    ucontext_t* uc = (ucontext_t*)ctx;
    uint64_t rip = uc->uc_mcontext.gregs[REG_RIP];
    uint64_t rax = uc->uc_mcontext.gregs[REG_RAX];
    uint64_t rcx = uc->uc_mcontext.gregs[REG_RCX];
    uint64_t rdx = uc->uc_mcontext.gregs[REG_RDX];
    uint64_t r8  = uc->uc_mcontext.gregs[REG_R8];
    uint64_t r9  = uc->uc_mcontext.gregs[REG_R9];
    uint64_t rsp = uc->uc_mcontext.gregs[REG_RSP];

    fprintf(stderr, "\n[CRASH] Signal %d at RIP=0x%lx\n", sig, rip);
    fprintf(stderr, "  RAX=0x%lx RCX=0x%lx RDX=0x%lx R8=0x%lx R9=0x%lx\n",
            rax, rcx, rdx, r8, r9);
    fprintf(stderr, "  RSP=0x%lx\n", rsp);

    if (g_image_base && rip >= (uint64_t)(uintptr_t)g_image_base &&
        rip < (uint64_t)(uintptr_t)g_image_base + g_image_size) {
        uint64_t rva = rip - (uint64_t)(uintptr_t)g_image_base;
        fprintf(stderr, "  RVA=0x%lx (inside loaded PE)\n", rva);

        /* Dump bytes at crash point */
        uint8_t* crash_ptr = (uint8_t*)(uintptr_t)rip;
        fprintf(stderr, "  Bytes: ");
        for (int i = 0; i < 16; i++) {
            fprintf(stderr, "%02x ", crash_ptr[i]);
        }
        fprintf(stderr, "\n");
    }

    /* Check if the crash is from calling a NULL function pointer */
    if (rip < 0x1000 || (info->si_code == SEGV_MAPERR && info->si_addr == NULL)) {
        fprintf(stderr, "  Likely: NULL function pointer call\n");
    }

    _exit(139);
}

static void setup_signal_handlers(void) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = crash_handler;
    sa.sa_flags = SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGILL, &sa, NULL);
    sigaction(SIGFPE, &sa, NULL);
    sigaction(SIGBUS, &sa, NULL);
    sigaction(SIGABRT, &sa, NULL);
}

/* ============================================================
 * Main
 * ============================================================ */

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("MiniWin PE Loader v0.1\n");
        printf("Usage: %s <pe_executable> [args...]\n", argv[0]);
        return 1;
    }

    const char* exe_path = argv[1];
    g_exe_path = exe_path;

    /* Build command line */
    snprintf(g_cmdline_ansi, sizeof(g_cmdline_ansi), "%s", exe_path);
    for (int i = 2; i < argc; i++) {
        strcat(g_cmdline_ansi, " ");
        strcat(g_cmdline_ansi, argv[i]);
    }
    MW_TRACE("Command line: %s", g_cmdline_ansi);

    /* Build wide command line */
    mbstowcs(g_cmdline_wide, g_cmdline_ansi, sizeof(g_cmdline_wide)/sizeof(wchar_t));

    /* Set up CRT data */
    g_acmdln_ptr = g_cmdline_ansi;
    g_initenv_ptr = NULL; /* no env for now */
    g_argv[0] = (char*)exe_path;
    for (int i = 2; i < argc; i++) {
        g_argv[i - 1] = argv[i];
    }
    g_argv[argc - 1] = NULL;
    g_argc = argc - 1;

    /* Set up signal handlers */
    setup_signal_handlers();

    /* Set up trace log */
    {
        char trace_path[512];
        const char* base = strrchr(exe_path, '/');
        base = base ? base + 1 : exe_path;
        snprintf(trace_path, sizeof(trace_path), "miniwin-results/%s/api_trace.json", base);
        /* Create directory if needed */
        char dir_path[512];
        snprintf(dir_path, sizeof(dir_path), "miniwin-results/%s", base);
        mkdir(dir_path, 0755);
        /* Also create subdirs */
        char subdir[600];
        snprintf(subdir, sizeof(subdir), "%s/execution", dir_path);
        mkdir(subdir, 0755);
        snprintf(subdir, sizeof(subdir), "%s/binary", dir_path);
        mkdir(subdir, 0755);
        snprintf(subdir, sizeof(subdir), "%s/analysis", dir_path);
        mkdir(subdir, 0755);
        snprintf(subdir, sizeof(subdir), "%s/screenshots", dir_path);
        mkdir(subdir, 0755);

        g_trace_log = fopen(trace_path, "w");
        if (g_trace_log) {
            fprintf(g_trace_log, "{\n  \"trace\": [\n");
        }
    }

    printf("[MiniWin] Loading %s...\n", exe_path);

    /* Load PE */
    if (load_pe(exe_path) != 0) {
        fprintf(stderr, "[ERROR] Failed to load PE\n");
        return 1;
